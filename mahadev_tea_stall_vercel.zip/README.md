# Mahadev Tea Stall — Vercel version

## Files
- `index.html`: website/menu/cart/order form
- `api/order.js`: Vercel serverless endpoint that sends order details to Telegram

## Deploy from a phone (GitHub + Vercel)
1. Download and extract this ZIP.
2. Upload the extracted files to a new GitHub repository. The `index.html` and `api` folder must be at the repository root.
3. On Vercel, choose Add New → Project, import that GitHub repository, and deploy. This is a plain HTML site plus a Vercel API function; no build command is needed.
4. In Vercel Project → Settings → Environment Variables, add:
   - `TELEGRAM_BOT_TOKEN` = your Telegram bot token
   - `TELEGRAM_CHAT_ID` = your private chat ID (or group chat ID)
   Select Production (and Preview if desired).
5. Redeploy after saving variables.
6. Open the website, add a menu item, fill in your details, and place a test order. Confirm that Telegram receives it.

## Find your Telegram chat ID
- Open your bot in Telegram and tap Start.
- Send the bot a message such as `test`.
- In a browser, open `https://api.telegram.org/botYOUR_BOT_TOKEN/getUpdates` after replacing `YOUR_BOT_TOKEN` with your token. Find `message.chat.id` in the JSON response. Do not share the URL or response publicly because the URL contains your secret token.
- If getUpdates shows no messages, send the bot another message and refresh. For group notifications, add the bot to the group, send a message there, and use the group's chat ID.
- Add the exact ID as `TELEGRAM_CHAT_ID`.

## Security
Never place the bot token in `index.html` or a public GitHub repository. If it has been exposed, revoke it with @BotFather and create a new token. Do not send your bot token in this chat.
